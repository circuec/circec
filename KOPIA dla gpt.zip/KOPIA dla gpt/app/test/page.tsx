export default function Test() {
  return <div>Test działa!</div>;
}