export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return children; // Dziedziczy style z głównego layout.tsx
}